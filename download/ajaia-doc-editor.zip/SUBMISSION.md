# Submission

**Candidate:** <!-- TODO: your name -->
**Date:** 2026-11-05
**Live URL:** <!-- TODO: paste your Vercel URL here, e.g. https://ajaia-docs.vercel.app -->
**Repository:** this repo (see commit history — one commit per milestone)

## Included files

| Path                     | What it is                                              |
| ------------------------ | ------------------------------------------------------- |
| `README.md`              | Setup, commands, demo accounts, API, deployment steps   |
| `ARCHITECTURE.md`        | Stack rationale, data/permission model, trade-offs      |
| `AI_WORKFLOW.md`         | How AI was used (candidate-filled template)             |
| `SUBMISSION.md`          | This file                                               |
| `WALKTHROUGH.txt`        | Video link placeholder                                  |
| `docs/VIDEO_SCRIPT.md`   | 3–5 minute video script outline                         |
| `docker-compose.yml`     | Local Postgres (alternative to Neon/Supabase)           |
| `.env.example`           | Required environment variables                          |
| `prisma/`                | Schema, initial migration, seed script                  |
| `src/`                   | Next.js app (pages, API routes, components, lib)        |
| `tests/`                 | Vitest suites + `.docx` fixture                         |

## Test credentials

All passwords: **`demo1234`**

- alice@demo.com (use for owner flows)
- bob@demo.com (use as share recipient)
- carol@demo.com (use as second share recipient / viewer)

## What works (verified end-to-end)

- Login with one-click demo accounts; logout; middleware redirects for
  unauthenticated users on every page and API route (401 JSON for `/api/*`).
- Dashboard with "My documents" / "Shared with me" tabs, Owner / "Shared by X"
  + role badges, updated times, empty/loading states.
- New document → TipTap editor with Bold / Italic / Underline / H1–H3 /
  bullet & numbered lists / undo-redo, active toolbar states.
- Autosave (~1s debounce) with Saving… / Saved / Error saving – retry;
  formatting persists across refresh (HTML in Postgres).
- Inline debounced rename with 1–120 char validation (client + server).
- Sharing: add by email with Viewer/Editor role, change role, revoke; errors
  for unknown user (404), self-share (400), duplicate (409); owner-only
  management (403 for editors/viewers).
- Viewers: read-only editor, disabled toolbar, "You have view-only access"
  banner; server returns 403 on any write attempt.
- Import: drag & drop or browse `.txt` / `.md` / `.docx` ≤ 2 MB → new document
  with headings/bold/italic/lists preserved; friendly rejections for
  unsupported types, oversize, empty, and corrupt files.
- Deletion (owner-only) with confirm; cascades shares.
- Tests: `npm run test` → 41 tests passing (access control, import conversion
  incl. real .docx fixture, shares API flow).
- `npm run lint`, `npm run typecheck`, and `npm run build` all clean.

## What is incomplete / known gaps

- No real-time collaboration, presence, or comments (deliberately cut; see
  `ARCHITECTURE.md`).
- Concurrent edits to the same document are last-write-wins (no OT/CRDT).
- Export (stretch) and version history (stretch) were not built; test depth
  was chosen instead.
- No rate limiting on login; sessions are not individually revocable.
- AI_WORKFLOW.md contains TODO placeholders for the candidate's own honest
  answers; SUBMISSION.md live URL is a placeholder until deployed.

## What I'd build next with 2–4 more hours

1. **Live updates between collaborators** — poll `GET /api/documents/[id]`
   with an `updatedAt` cursor (or SSE) and merge remote HTML so viewers/editors
   see changes without a refresh. Cheap first step toward real-time.
2. **Version history** — append-only `DocumentVersion` table written on each
   autosave (or every N minutes), with a simple restore button. Low risk,
   high demo value.
3. **Export to Markdown** — server-side HTML→MD (`turndown`) behind
   `GET /api/documents/[id]/export`, reusing the import pipeline in reverse.
4. **Hardening** — login rate limiting, per-request Zod parse logging,
   Playwright E2E covering the QA script below, and Vercel Cron for pruning
   old versions.

## Manual QA script (sharing flow demo)

1. Open the deployed URL (or `npm run dev`).
2. **Alice**: one-click sign in as `alice@demo.com` from the Demo accounts box.
3. Click **+ New document** → type a heading, bold text, and a list; watch
   **Saving… → Saved**; reload the page → formatting is still there.
4. Rename via the inline title (e.g. "Project Phoenix") → Saved; reload →
   title persists.
5. Click **Share** → enter `bob@demo.com`, role **Viewer** → Add.
   - Try `ghost@demo.com` → "No user was found with that email address."
   - Try `alice@demo.com` → "You cannot share a document with yourself."
   - Add Bob again → "That user already has access to this document."
6. Log out → sign in as **Bob**. The document appears under
   **Shared with me** with "Shared by Alice" + **Viewer** badge.
7. Open it → banner "You have view-only access", toolbar disabled, title input
   disabled. Try typing → nothing changes.
8. Log out → **Alice** → Share → change Bob's role to **Editor**.
9. Log out → **Bob** → reload the document → banner gone, toolbar enabled,
   title editable. Edit content and the title → Saved.
10. As Bob: confirm there is no Share button and no Delete button; the API
    blocks it anyway (403).
11. Log out → **Alice** → open the document → Share → **Remove** Bob → Done.
12. As Bob: reload → the document is gone from "Shared with me".
13. Back as Alice: **Import file** → drop a `.docx` (or `.md`) → the converted
    document opens with formatting intact.
14. Alice: **Delete** the original document → confirm → back on dashboard.
