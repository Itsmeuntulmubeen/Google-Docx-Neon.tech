# Ajaia Docs — lightweight collaborative document editor

A Google Docs–inspired editor built as a take-home assignment: create and edit
rich-text documents, autosave, import `.txt` / `.md` / `.docx` files, and share
documents with other users as **Viewer** or **Editor** — with permissions
enforced on the server.

## Demo accounts

All accounts use the password **`demo1234`**. The login page has a "Demo
accounts" box with one-click sign in.

| Name  | Email           | Password    |
| ----- | --------------- | ----------- |
| Alice | alice@demo.com  | `demo1234`  |
| Bob   | bob@demo.com    | `demo1234`  |
| Carol | carol@demo.com  | `demo1234`  |

## Features

- **Auth (simulated):** 3 seeded users, JWT session in a signed `httpOnly`
  cookie (`jose`, HS256, 7 days). Middleware protects every app page and API
  route.
- **Documents:** dashboard with "My documents" / "Shared with me" tabs,
  Owner / *Shared by …* badges with role, relative "Updated" times, empty and
  loading states.
- **Editing:** TipTap editor (StarterKit + Underline) with Bold, Italic,
  Underline, H1/H2/H3, bullet & numbered lists, undo/redo — active states
  highlighted. Autosave after ~1s of inactivity with **Saving… / Saved /
  Error saving – retry** status. Inline, debounced title rename (1–120 chars).
- **Sharing:** owners invite existing users by email with a role
  (Viewer/Editor), change roles, revoke access. Friendly errors for unknown
  user, self-share, and duplicate share. Viewers get a read-only editor with a
  "You have view-only access" banner.
- **Import:** drag & drop (or browse) `.txt`, `.md`, `.docx` up to 2 MB →
  converted to a new editable document; HTML is sanitized server-side before
  storage.
- **Content is stored as sanitized HTML** in Postgres, so formatting survives
  refreshes and round-trips through import.

**Supported upload types: `.txt`, `.md`, `.docx` — max 2 MB.**

## Tech stack

| Layer      | Choice                                                    |
| ---------- | --------------------------------------------------------- |
| Framework  | Next.js 15 (App Router) + TypeScript (strict) + Tailwind 4 |
| Editor     | TipTap v2 (`@tiptap/starter-kit` + `@tiptap/extension-underline`) |
| Database   | PostgreSQL via Prisma 6 (Neon / Supabase / local Docker)  |
| Auth       | `jose` JWT in signed httpOnly cookie, `bcryptjs` hashing  |
| Validation | `zod` on every API input                                  |
| Import     | `mammoth` (.docx), `marked` (.md), `sanitize-html`        |
| Tests      | Vitest (41 tests)                                         |

## Prerequisites

- Node.js 18.18+ (developed on Node 24)
- A PostgreSQL database — either
  - **Docker** for a local DB (`docker-compose.yml` provided), or
  - a free **Neon** / **Supabase** database (works for local and production)

## Local setup

```bash
# 1. Install dependencies (also runs `prisma generate`)
npm install

# 2. Configure environment
cp .env.example .env
#   - set DATABASE_URL to your Postgres connection string
#   - set AUTH_SECRET to something random: openssl rand -base64 32

# 3a. Local database via Docker
docker compose up -d          # Postgres on localhost:5432 (db: docs)
# …then use: postgresql://postgres:postgres@localhost:5432/docs?schema=public

# 3b. …or use a Neon/Supabase connection string directly (same for local & prod)

# 4. Create the schema and seed demo users
npm run db:migrate            # applies migrations in dev
npm run db:seed               # seeds alice / bob / carol

# 5. Run
npm run dev                   # http://localhost:3000
```

### All commands

| Command             | What it does                          |
| ------------------- | ------------------------------------- |
| `npm run dev`       | Dev server                            |
| `npm run build`     | `prisma generate` + production build  |
| `npm run start`     | Serve the production build            |
| `npm run lint`      | ESLint (next/core-web-vitals + TS)    |
| `npm run typecheck` | `tsc --noEmit` (strict)               |
| `npm run test`      | Vitest, single run                    |
| `npm run test:watch`| Vitest in watch mode                  |
| `npm run db:migrate`| `prisma migrate dev` (create/apply)   |
| `npm run db:deploy` | `prisma migrate deploy` (CI/production) |
| `npm run db:seed`   | Seed the 3 demo users                 |
| `npm run db:studio` | Prisma Studio (browse data)           |

### Environment variables (`.env`)

| Variable       | Purpose                                              |
| -------------- | ---------------------------------------------------- |
| `DATABASE_URL` | Postgres connection string (Neon/Supabase/local)     |
| `AUTH_SECRET`  | HMAC secret for signing session JWTs                 |

See `.env.example`.

## Tests

```bash
npm run test
```

- `tests/access.test.ts` — the `getDocumentAccess` permission helper
  (owner / editor / viewer / no access / missing document).
- `tests/import.test.ts` — upload validation (extension, MIME, size, empty),
  `.txt` and `.md` conversion, `.docx` conversion against a real fixture
  (`tests/fixtures/sample.docx`), title derivation.
- `tests/shares-api.test.ts` — API-level tests for the sharing flow: the route
  handlers are invoked directly with a mocked DB/session and cover 403 for
  non-owners, self-share, unknown user, duplicate share, role change, and
  removal.

## Deployment (GitHub → Vercel + Neon, free tier)

### 1. Push to GitHub

Create an empty **private** repo on [github.com/new](https://github.com/new)
(do **not** tick "Add a README" — the repo already has history), then:

```bash
git remote add origin https://github.com/<your-username>/ajaia-docs.git
git push -u origin main
```

Or with the GitHub CLI: `gh auth login`, then
`gh repo create ajaia-docs --private --source=. --remote=origin --push`.

### 2. Create the database

Sign up at [neon.tech](https://neon.tech) and create a project. Neon shows two
connection strings — you need **both**:

- **Pooled** (host contains `-pooler`) → for Vercel runtime
- **Direct / unpooled** (no `-pooler`) → for running migrations & seed

### 3. Import into Vercel

[vercel.com/new](https://vercel.com/new) → "Import Git Repository" → select the
repo. Framework preset **Next.js** is auto-detected; build/install defaults are
fine (`npm run build` already runs `prisma generate`, as does `postinstall`).

### 4. Set environment variables

Project → Settings → Environment Variables (add for Production **and**
Preview):

| Variable       | Value                                              |
| -------------- | -------------------------------------------------- |
| `DATABASE_URL` | Neon **pooled** string (`postgresql://…-pooler…?sslmode=require`) |
| `AUTH_SECRET`  | output of `openssl rand -base64 32`                 |

### 5. Apply migrations + seed to the production DB (once, from your machine)

```bash
# use the DIRECT (unpooled) Neon URL here
DATABASE_URL="<neon-direct-url>" npx prisma migrate deploy
DATABASE_URL="<neon-direct-url>" npm run db:seed
```

### 6. Deploy

Click **Deploy** (or just `git push` — every push to `main` redeploys). When
the build finishes, open the URL and sign in with a demo account
(`alice@demo.com` / `demo1234`). If you had already deployed before setting the
env vars, trigger "Redeploy" so they take effect.

> Tip: the pooled URL is required for serverless (Vercel) because Neon's pooler
> runs PgBouncer in transaction mode; if Prisma logs "prepared statement"
> errors at runtime, you are on the wrong URL. Migrations must go through the
> direct URL.

## API overview

All errors share one shape: `{ "error": string }`.

| Method & path                          | Who                | Notes |
| -------------------------------------- | ------------------ | ----- |
| `POST /api/auth/login`                 | public             | `{email, password}` → sets session cookie |
| `POST /api/auth/logout`                | public             | clears the session cookie |
| `GET /api/documents`                   | any signed-in user | `{owned: […], shared: […]}` |
| `POST /api/documents`                  | any signed-in user | creates "Untitled document" |
| `GET /api/documents/[id]`              | owner/editor/viewer | doc + `access` level; 404 if no access |
| `PATCH /api/documents/[id]`            | owner/editor       | partial `{title?, content?}`; 403 for viewers |
| `DELETE /api/documents/[id]`           | owner              | 403 otherwise |
| `GET /api/documents/[id]/shares`       | owner              | collaborator list |
| `POST /api/documents/[id]/shares`      | owner              | `{email, role}`; 400 self, 404 unknown user, 409 duplicate |
| `PATCH /api/documents/[id]/shares`     | owner              | `{userId, role}` |
| `DELETE /api/documents/[id]/shares?userId=…` | owner        | revoke access |
| `POST /api/import`                     | any signed-in user | multipart `file`; `.txt`/`.md`/`.docx`, ≤ 2 MB |

Permissions are enforced **on the server** in every route via the central
`getDocumentAccess(userId, documentId)` helper (`src/lib/access.ts`).

## Project structure

```
src/
├── middleware.ts                  # auth gate for pages + API
├── app/
│   ├── page.tsx                   # dashboard (server component)
│   ├── login/page.tsx             # login + demo accounts
│   ├── documents/[id]/page.tsx    # editor page
│   └── api/                       # auth, documents, shares, import routes
├── components/
│   ├── Header.tsx, ui/Toast.tsx
│   ├── dashboard/                 # DashboardClient, ImportModal
│   └── editor/                    # DocumentEditor, Toolbar, ShareModal
└── lib/
    ├── session.ts, auth.ts, db.ts # JWT primitives, cookie session, Prisma
    ├── access.ts                  # getDocumentAccess (single source of truth)
    ├── documents.ts, import.ts, validation.ts, api.ts
prisma/                            # schema, migration, seed
tests/                             # Vitest suites + .docx fixture
```

## Known limitations

See `ARCHITECTURE.md` (§ "What was deliberately cut" and § "Known limitations").
