import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

/**
 * API-level tests for the sharing routes. The prisma client and the session
 * helper are mocked, and the route handlers are invoked directly — no HTTP
 * server or database needed, but the full request path (auth → permission
 * check → validation → prisma call → response) is exercised.
 */

const { prismaMock, getSessionUserMock } = vi.hoisted(() => ({
  prismaMock: {
    document: { findUnique: vi.fn() },
    user: { findUnique: vi.fn() },
    documentShare: {
      findUnique: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
      findMany: vi.fn(),
    },
  },
  getSessionUserMock: vi.fn(),
}));

vi.mock("@/lib/db", () => ({ prisma: prismaMock }));
vi.mock("@/lib/auth", () => ({ getSessionUser: getSessionUserMock }));

import {
  DELETE,
  GET,
  PATCH,
  POST,
} from "@/app/api/documents/[id]/shares/route";

const OWNER = { userId: "user-owner", email: "alice@demo.com", name: "Alice" };
const DOCUMENT_ID = "doc-1";
const routeContext = { params: Promise.resolve({ id: DOCUMENT_ID }) };

function postRequest(body: unknown) {
  return new NextRequest(`http://localhost/api/documents/${DOCUMENT_ID}/shares`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function patchRequest(body: unknown) {
  return new NextRequest(`http://localhost/api/documents/${DOCUMENT_ID}/shares`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function deleteRequest(userId: string) {
  return new NextRequest(
    `http://localhost/api/documents/${DOCUMENT_ID}/shares?userId=${userId}`,
    { method: "DELETE" },
  );
}

function ownerDb() {
  prismaMock.document.findUnique.mockResolvedValue({
    ownerId: OWNER.userId,
    shares: [],
  });
}

beforeEach(() => {
  getSessionUserMock.mockResolvedValue(OWNER);
  vi.clearAllMocks();
  getSessionUserMock.mockResolvedValue(OWNER);
  ownerDb();
});

describe("POST /api/documents/[id]/shares", () => {
  it("returns 403 when the caller is not the owner", async () => {
    prismaMock.document.findUnique.mockResolvedValue({
      ownerId: "someone-else",
      shares: [{ role: "VIEWER" }],
    });

    const res = await POST(
      postRequest({ email: "bob@demo.com", role: "VIEWER" }),
      routeContext,
    );
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error: string };
    expect(body.error).toMatch(/Only the owner/);
  });

  it("returns 404 when the caller has no access at all", async () => {
    prismaMock.document.findUnique.mockResolvedValue(null);

    const res = await POST(
      postRequest({ email: "bob@demo.com", role: "VIEWER" }),
      routeContext,
    );
    expect(res.status).toBe(404);
  });

  it("returns 400 when sharing with yourself", async () => {
    const res = await POST(
      postRequest({ email: OWNER.email, role: "VIEWER" }),
      routeContext,
    );
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error: string };
    expect(body.error).toMatch(/yourself/i);
  });

  it("returns 404 when the target user does not exist", async () => {
    prismaMock.user.findUnique.mockResolvedValue(null);

    const res = await POST(
      postRequest({ email: "ghost@demo.com", role: "VIEWER" }),
      routeContext,
    );
    expect(res.status).toBe(404);
    const body = (await res.json()) as { error: string };
    expect(body.error).toMatch(/No user was found/);
  });

  it("returns 409 when the user already has access", async () => {
    prismaMock.user.findUnique.mockResolvedValue({
      id: "user-bob",
      email: "bob@demo.com",
      name: "Bob",
    });
    prismaMock.documentShare.findUnique.mockResolvedValue({
      documentId: DOCUMENT_ID,
      userId: "user-bob",
      role: "VIEWER",
    });

    const res = await POST(
      postRequest({ email: "bob@demo.com", role: "EDITOR" }),
      routeContext,
    );
    expect(res.status).toBe(409);
    const body = (await res.json()) as { error: string };
    expect(body.error).toMatch(/already has access/);
  });

  it("creates the share and returns 201 on success", async () => {
    prismaMock.user.findUnique.mockResolvedValue({
      id: "user-bob",
      email: "bob@demo.com",
      name: "Bob",
    });
    prismaMock.documentShare.findUnique.mockResolvedValue(null);
    prismaMock.documentShare.create.mockResolvedValue({
      documentId: DOCUMENT_ID,
      userId: "user-bob",
      role: "EDITOR",
      user: { name: "Bob", email: "bob@demo.com" },
    });

    const res = await POST(
      postRequest({ email: "bob@demo.com", role: "EDITOR" }),
      routeContext,
    );
    expect(res.status).toBe(201);
    const body = (await res.json()) as { share: { role: string; email: string } };
    expect(body.share.role).toBe("EDITOR");
    expect(body.share.email).toBe("bob@demo.com");
    expect(prismaMock.documentShare.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ role: "EDITOR" }),
      }),
    );
  });

  it("returns 400 for an invalid email", async () => {
    const res = await POST(
      postRequest({ email: "not-an-email", role: "VIEWER" }),
      routeContext,
    );
    expect(res.status).toBe(400);
  });
});

describe("PATCH /api/documents/[id]/shares", () => {
  it("changes the role for an existing collaborator", async () => {
    prismaMock.documentShare.findUnique.mockResolvedValue({
      documentId: DOCUMENT_ID,
      userId: "user-bob",
      role: "VIEWER",
    });
    prismaMock.documentShare.update.mockResolvedValue({
      documentId: DOCUMENT_ID,
      userId: "user-bob",
      role: "EDITOR",
      user: { name: "Bob", email: "bob@demo.com" },
    });

    const res = await PATCH(
      patchRequest({ userId: "user-bob", role: "EDITOR" }),
      routeContext,
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { share: { role: string } };
    expect(body.share.role).toBe("EDITOR");
  });

  it("returns 404 for a user without access", async () => {
    prismaMock.documentShare.findUnique.mockResolvedValue(null);

    const res = await PATCH(
      patchRequest({ userId: "user-bob", role: "EDITOR" }),
      routeContext,
    );
    expect(res.status).toBe(404);
  });
});

describe("DELETE /api/documents/[id]/shares", () => {
  it("removes access for an existing collaborator", async () => {
    prismaMock.documentShare.findUnique.mockResolvedValue({
      documentId: DOCUMENT_ID,
      userId: "user-bob",
      role: "VIEWER",
    });
    prismaMock.documentShare.delete.mockResolvedValue({});

    const res = await DELETE(deleteRequest("user-bob"), routeContext);
    expect(res.status).toBe(200);
    expect(prismaMock.documentShare.delete).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          documentId_userId: { documentId: DOCUMENT_ID, userId: "user-bob" },
        },
      }),
    );
  });

  it("returns 404 when the collaborator does not exist", async () => {
    prismaMock.documentShare.findUnique.mockResolvedValue(null);

    const res = await DELETE(deleteRequest("user-bob"), routeContext);
    expect(res.status).toBe(404);
  });

  it("returns 400 when the userId query parameter is missing", async () => {
    const res = await DELETE(
      new NextRequest(`http://localhost/api/documents/${DOCUMENT_ID}/shares`, {
        method: "DELETE",
      }),
      routeContext,
    );
    expect(res.status).toBe(400);
  });
});

describe("GET /api/documents/[id]/shares", () => {
  it("lists collaborators for the owner", async () => {
    prismaMock.documentShare.findMany.mockResolvedValue([
      {
        documentId: DOCUMENT_ID,
        userId: "user-bob",
        role: "VIEWER",
        user: { name: "Bob", email: "bob@demo.com" },
      },
    ]);

    const res = await GET(
      new NextRequest(`http://localhost/api/documents/${DOCUMENT_ID}/shares`),
      routeContext,
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      shares: { email: string; role: string }[];
    };
    expect(body.shares).toHaveLength(1);
    expect(body.shares[0].email).toBe("bob@demo.com");
  });
});
