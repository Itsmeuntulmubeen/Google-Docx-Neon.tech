import { describe, expect, it, vi } from "vitest";
import type { PrismaClient } from "@prisma/client";
import { getDocumentAccess } from "@/lib/access";

/** Builds a minimal fake Prisma client whose `document.findUnique` returns `doc`. */
function fakeDb(doc: unknown) {
  return {
    document: { findUnique: vi.fn().mockResolvedValue(doc) },
  } as unknown as Pick<PrismaClient, "document">;
}

describe("getDocumentAccess", () => {
  const documentId = "doc-1";

  it("returns 'owner' when the user owns the document (even if a stray share exists)", async () => {
    const db = fakeDb({
      ownerId: "user-1",
      shares: [{ role: "VIEWER" }],
    });
    const access = await getDocumentAccess(db, "user-1", documentId);
    expect(access).toBe("owner");
  });

  it("returns 'editor' when the user has an EDITOR share", async () => {
    const db = fakeDb({
      ownerId: "user-1",
      shares: [{ role: "EDITOR" }],
    });
    const access = await getDocumentAccess(db, "user-2", documentId);
    expect(access).toBe("editor");
  });

  it("returns 'viewer' when the user has a VIEWER share", async () => {
    const db = fakeDb({
      ownerId: "user-1",
      shares: [{ role: "VIEWER" }],
    });
    const access = await getDocumentAccess(db, "user-2", documentId);
    expect(access).toBe("viewer");
  });

  it("returns null when the document exists but the user has no share", async () => {
    const db = fakeDb({ ownerId: "user-1", shares: [] });
    const access = await getDocumentAccess(db, "user-2", documentId);
    expect(access).toBeNull();
  });

  it("returns null when the document does not exist", async () => {
    const db = fakeDb(null);
    const access = await getDocumentAccess(db, "user-1", documentId);
    expect(access).toBeNull();
  });

  it("queries the database by document id", async () => {
    const db = fakeDb({ ownerId: "user-1", shares: [] });
    await getDocumentAccess(db, "user-1", documentId);
    expect(db.document.findUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: documentId } }),
    );
  });
});
