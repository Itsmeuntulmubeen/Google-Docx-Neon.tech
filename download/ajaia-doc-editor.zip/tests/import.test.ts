import { describe, expect, it } from "vitest";
import { readFile } from "node:fs/promises";
import path from "node:path";
import {
  MAX_UPLOAD_BYTES,
  docxToHtml,
  mdToHtml,
  titleFromFilename,
  txtToHtml,
  validateUpload,
} from "@/lib/import";

describe("validateUpload", () => {
  it("accepts a plain text file", () => {
    expect(
      validateUpload({ name: "notes.txt", size: 10, type: "text/plain" }),
    ).toBeNull();
  });

  it("accepts a markdown file with a markdown MIME type", () => {
    expect(
      validateUpload({ name: "readme.md", size: 10, type: "text/markdown" }),
    ).toBeNull();
  });

  it("accepts a docx with the Office MIME type", () => {
    expect(
      validateUpload({
        name: "report.docx",
        size: 10,
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      }),
    ).toBeNull();
  });

  it("accepts an empty MIME type (some clients send none)", () => {
    expect(
      validateUpload({ name: "notes.txt", size: 10, type: "" }),
    ).toBeNull();
  });

  it("accepts application/octet-stream (common for .docx on some OSes)", () => {
    expect(
      validateUpload({
        name: "report.docx",
        size: 10,
        type: "application/octet-stream",
      }),
    ).toBeNull();
  });

  it("rejects unsupported extensions", () => {
    const error = validateUpload({
      name: "malware.exe",
      size: 10,
      type: "application/octet-stream",
    });
    expect(error).toMatch(/Unsupported file type/);
  });

  it("rejects files with no extension", () => {
    expect(validateUpload({ name: "README", size: 10, type: "" })).toMatch(
      /Unsupported file type/,
    );
  });

  it("rejects oversized files", () => {
    const error = validateUpload({
      name: "big.txt",
      size: MAX_UPLOAD_BYTES + 1,
      type: "text/plain",
    });
    expect(error).toMatch(/too large/);
  });

  it("rejects empty files", () => {
    expect(
      validateUpload({ name: "empty.txt", size: 0, type: "text/plain" }),
    ).toMatch(/empty/);
  });

  it("rejects a .txt whose MIME type is an image", () => {
    const error = validateUpload({
      name: "notes.txt",
      size: 10,
      type: "image/png",
    });
    expect(error).toMatch(/does not look like a \.txt file/);
  });
});

describe("txtToHtml", () => {
  it("wraps each line in a paragraph", () => {
    expect(txtToHtml("Hello\nWorld")).toBe("<p>Hello</p><p>World</p>");
  });

  it("escapes HTML so pasted markup cannot inject tags", () => {
    const html = txtToHtml("<script>alert(1)</script>");
    expect(html).not.toContain("<script>");
    expect(html).toContain("&lt;script&gt;");
  });

  it("keeps blank lines as empty paragraphs", () => {
    expect(txtToHtml("a\n\nb")).toBe("<p>a</p><p><br></p><p>b</p>");
  });
});

describe("mdToHtml", () => {
  it("converts headings", () => {
    expect(mdToHtml("# Title")).toContain("<h1>Title</h1>");
    expect(mdToHtml("## Sub")).toContain("<h2>Sub</h2>");
  });

  it("converts bold and italic", () => {
    expect(mdToHtml("**bold** and *italic*")).toContain("<strong>bold</strong>");
    expect(mdToHtml("**bold** and *italic*")).toContain("<em>italic</em>");
  });

  it("converts lists", () => {
    const html = mdToHtml("- one\n- two");
    expect(html).toContain("<ul>");
    expect(html).toContain("<li>one</li>");
  });
});

describe("docxToHtml", () => {
  it("preserves headings, bold, and italics from a real .docx file", async () => {
    const fixturePath = path.join(__dirname, "fixtures", "sample.docx");
    const buffer = await readFile(fixturePath);
    const html = await docxToHtml(buffer);

    expect(html).toContain("<h1>Project Phoenix</h1>");
    expect(html).toContain("<h2>Overview</h2>");
    expect(html).toContain("<strong>bold</strong>");
    expect(html).toContain("<em>italic</em>");
  });

  it("fails with an error for a file that is not a real .docx", async () => {
    const notADocx = Buffer.from("definitely not a zip archive");
    await expect(docxToHtml(notADocx)).rejects.toThrow();
  });
});

describe("titleFromFilename", () => {
  it("strips the extension", () => {
    expect(titleFromFilename("Meeting Notes.docx")).toBe("Meeting Notes");
  });

  it("handles names without an extension", () => {
    expect(titleFromFilename("README")).toBe("README");
  });

  it("falls back to a default for an empty base name", () => {
    expect(titleFromFilename(".md")).toBe("Untitled document");
  });

  it("caps the title at 120 characters", () => {
    const long = "A".repeat(200);
    expect(titleFromFilename(`${long}.txt`).length).toBeLessThanOrEqual(120);
  });
});
