# AI Workflow

> How AI was used while building this take-home. Filled in honestly by the
> candidate — TODO markers below are deliberate placeholders.

## Tools used

<!-- TODO: List the AI tools/models you actually used (e.g. "z.ai agent mode
with GLM", "Cursor + Claude", "ChatGPT o3", etc.), and roughly how much of the
total time you spent with AI assistance. -->

- **TODO:** …

## Where AI sped me up

<!-- TODO: Be concrete. Examples of the kind of thing to write:
- "Scaffolded the Next.js + Prisma + Vitest project skeleton in minutes instead of an hour of copy-paste."
- "Generated the first draft of the zod schemas and the shares route handler, which I then adjusted."
- "Explained the Next.js 15 async cookies()/params gotchas before I hit them."
Which parts of THIS project did AI genuinely accelerate? -->

- **TODO:** …
- **TODO:** …

## What AI output I changed or rejected

<!-- TODO: Be honest here — reviewers value judgment over obedience.
Examples of the kind of thing to write:
- "It suggested storing TipTap JSON; I chose sanitized HTML instead because import round-trips were simpler."
- "It reached for a state library for toasts; a 40-line context was enough."
- "It hallucinated an API for TipTap v3; I pinned v2 and checked the docs."
What did you actually override in this codebase, and why? -->

- **TODO:** …
- **TODO:** …

## How I verified correctness, UX, and reliability

<!-- TODO: Describe YOUR verification process. Things worth mentioning if true:
- Ran `npm run lint`, `typecheck`, `test`, and a production build after each milestone.
- The included Vitest suites (access control, import conversion with a real .docx fixture, shares API).
- Manual QA: logged in as each demo user, exercised the sharing flow (viewer → editor upgrade),
  uploaded .txt/.md/.docx and unsupported/oversize files, checked autosave status transitions,
  refresh-persistence, and mobile widths.
- Anything you deployed and clicked through on Vercel.
What did YOU actually run and observe? -->

- **TODO:** …
- **TODO:** …

## What I would do differently with more AI (or less)

<!-- TODO: Optional — one or two sentences. -->
- **TODO:** …
