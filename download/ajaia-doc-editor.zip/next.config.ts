import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep native/CJS-heavy server-only packages out of the bundler.
  serverExternalPackages: ["@prisma/client", "mammoth", "sanitize-html"],
};

export default nextConfig;
