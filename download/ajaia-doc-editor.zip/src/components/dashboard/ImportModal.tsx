"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/Toast";

const ACCEPTED = ".txt,.md,.docx";
const SUPPORTED_TEXT = "Supported: .txt, .md, .docx, max 2 MB";

export default function ImportModal({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const toast = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function upload(file: File) {
    setError(null);
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      const res = await fetch("/api/import", { method: "POST", body });
      const data = (await res.json().catch(() => null)) as
        | { document?: { id: string }; error?: string }
        | null;
      if (!res.ok || !data?.document) {
        setError(data?.error ?? "Import failed. Please try again.");
        return;
      }
      toast("Document imported.", "success");
      router.push(`/documents/${data.document.id}`);
    } catch {
      setError("Network error while uploading.");
    } finally {
      setUploading(false);
    }
  }

  function handleFile(file: File | undefined) {
    if (file) void upload(file);
  }

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl"
        role="dialog"
        aria-modal="true"
        aria-label="Import a file"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold">Import a file</h2>
            <p className="mt-0.5 text-sm text-gray-500">{SUPPORTED_TEXT}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-lg p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-600"
          >
            ✕
          </button>
        </div>

        <div
          role="button"
          tabIndex={0}
          aria-label="Choose a file to import"
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            handleFile(e.dataTransfer.files?.[0]);
          }}
          className={`mt-4 flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition ${
            dragging
              ? "border-blue-400 bg-blue-50"
              : "border-gray-300 bg-gray-50 hover:border-gray-400"
          }`}
        >
          <span className="text-2xl" aria-hidden>
            ⬆️
          </span>
          {uploading ? (
            <p className="mt-2 text-sm font-medium text-blue-700">
              Importing…
            </p>
          ) : (
            <>
              <p className="mt-2 text-sm font-medium text-gray-700">
                Drag & drop a file here, or click to browse
              </p>
              <p className="mt-1 text-xs text-gray-500">{SUPPORTED_TEXT}</p>
            </>
          )}
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPTED}
            className="hidden"
            onChange={(e) => {
              handleFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </div>

        {error && (
          <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
            {error}
          </p>
        )}

        <p className="mt-3 text-xs text-gray-400">
          The file is converted into a new editable document owned by you.
          Headings, bold, italics, and lists are preserved where possible.
        </p>
      </div>
    </div>
  );
}
