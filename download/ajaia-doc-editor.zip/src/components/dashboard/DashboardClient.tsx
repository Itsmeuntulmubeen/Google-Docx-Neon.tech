"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/Toast";
import ImportModal from "./ImportModal";
import type { OwnedDocumentItem, SharedDocumentItem } from "@/lib/documents";

type Props = {
  owned: OwnedDocumentItem[];
  shared: SharedDocumentItem[];
};

type Tab = "mine" | "shared";

function OwnerBadge() {
  return (
    <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
      Owner
    </span>
  );
}

function SharedBadge({ item }: { item: SharedDocumentItem }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
        Shared by {item.ownerName}
      </span>
      <span
        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
          item.role === "Editor"
            ? "bg-green-100 text-green-700"
            : "bg-amber-100 text-amber-700"
        }`}
      >
        {item.role}
      </span>
    </span>
  );
}

function DocumentRow({
  href,
  title,
  updatedAtLabel,
  badge,
}: {
  href: string;
  title: string;
  updatedAtLabel: string;
  badge: React.ReactNode;
}) {
  return (
    <li className="border-b border-gray-100 last:border-0">
      <Link
        href={href}
        className="flex items-center justify-between gap-4 px-4 py-3 transition hover:bg-gray-50"
      >
        <div className="min-w-0">
          <p className="truncate font-medium text-gray-900">{title}</p>
          <p className="mt-0.5 text-xs text-gray-500">
            Updated {updatedAtLabel}
          </p>
        </div>
        <div className="shrink-0">{badge}</div>
      </Link>
    </li>
  );
}

export default function DashboardClient({ owned, shared }: Props) {
  const router = useRouter();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>("mine");
  const [creating, setCreating] = useState(false);
  const [importOpen, setImportOpen] = useState(false);

  async function createDocument() {
    setCreating(true);
    try {
      const res = await fetch("/api/documents", { method: "POST" });
      const data = (await res.json().catch(() => null)) as {
        document?: { id: string };
        error?: string;
      } | null;
      if (!res.ok || !data?.document) {
        toast(data?.error ?? "Could not create the document.");
        return;
      }
      router.push(`/documents/${data.document.id}`);
    } catch {
      toast("Network error while creating the document.");
    } finally {
      setCreating(false);
    }
  }

  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: "mine", label: "My documents", count: owned.length },
    { key: "shared", label: "Shared with me", count: shared.length },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Documents</h1>
          <p className="mt-0.5 text-sm text-gray-500">
            Create, edit, and share documents with your team.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setImportOpen(true)}
            className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
            title="Supported: .txt, .md, .docx, max 2 MB"
          >
            Import file
          </button>
          <button
            type="button"
            onClick={() => void createDocument()}
            disabled={creating}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {creating ? "Creating…" : "+ New document"}
          </button>
        </div>
      </div>

      <div className="mt-6 flex gap-1 border-b border-gray-200" role="tablist">
        {tabs.map(({ key, label, count }) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={tab === key}
            onClick={() => setTab(key)}
            className={`-mb-px rounded-t-lg px-4 py-2 text-sm font-medium transition ${
              tab === key
                ? "border-b-2 border-blue-600 text-blue-700"
                : "border-b-2 border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {label}{" "}
            <span className="ml-1 rounded-full bg-gray-100 px-1.5 py-0.5 text-xs text-gray-600">
              {count}
            </span>
          </button>
        ))}
      </div>

      {importOpen && <ImportModal onClose={() => setImportOpen(false)} />}

      {tab === "mine" ? (
        owned.length > 0 ? (
          <ul className="mt-4 divide-y divide-gray-100 rounded-xl border border-gray-200 bg-white shadow-sm">
            {owned.map((doc) => (
              <DocumentRow
                key={doc.id}
                href={`/documents/${doc.id}`}
                title={doc.title}
                updatedAtLabel={doc.updatedAtLabel}
                badge={<OwnerBadge />}
              />
            ))}
          </ul>
        ) : (
          <div className="mt-4 rounded-xl border border-dashed border-gray-300 bg-white p-12 text-center">
            <p className="font-medium text-gray-900">No documents yet</p>
            <p className="mt-1 text-sm text-gray-500">
              Create your first document, or import a .txt, .md, or .docx file.
            </p>
            <button
              type="button"
              onClick={() => void createDocument()}
              disabled={creating}
              className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60"
            >
              {creating ? "Creating…" : "+ New document"}
            </button>
          </div>
        )
      ) : shared.length > 0 ? (
        <ul className="mt-4 divide-y divide-gray-100 rounded-xl border border-gray-200 bg-white shadow-sm">
          {shared.map((doc) => (
            <DocumentRow
              key={doc.id}
              href={`/documents/${doc.id}`}
              title={doc.title}
              updatedAtLabel={doc.updatedAtLabel}
              badge={<SharedBadge item={doc} />}
            />
          ))}
        </ul>
      ) : (
        <div className="mt-4 rounded-xl border border-dashed border-gray-300 bg-white p-12 text-center">
          <p className="font-medium text-gray-900">Nothing shared with you yet</p>
          <p className="mt-1 text-sm text-gray-500">
            When someone shares a document with you, it will show up here.
          </p>
        </div>
      )}
    </div>
  );
}
