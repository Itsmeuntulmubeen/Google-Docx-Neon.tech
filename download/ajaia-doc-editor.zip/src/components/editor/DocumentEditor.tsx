"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { useToast } from "@/components/ui/Toast";
import ShareModal from "./ShareModal";
import Toolbar from "./Toolbar";
import type { AccessLevel } from "@/lib/access";

export type EditorDoc = {
  id: string;
  title: string;
  content: string;
  ownerName: string;
  updatedAtLabel: string;
};

type Props = {
  doc: EditorDoc;
  access: AccessLevel;
};

type SaveStatus = "saved" | "saving" | "error";

const CONTENT_SAVE_DELAY_MS = 1000;
const TITLE_SAVE_DELAY_MS = 600;

export default function DocumentEditor({ doc, access }: Props) {
  const canEdit = access !== "viewer";
  const isOwner = access === "owner";
  const router = useRouter();
  const toast = useToast();

  const [title, setTitle] = useState(doc.title);
  const savedTitle = useRef(doc.title);
  const [status, setStatus] = useState<SaveStatus>("saved");
  const [deleting, setDeleting] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  // A single promise chain serializes every PATCH so an older request can
  // never overwrite a newer one (e.g. title save racing a content save).
  const saveQueue = useRef<Promise<unknown>>(Promise.resolve());
  const contentTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingContent = useRef<string | null>(null);
  const titleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const patch = useCallback(
    (body: Record<string, string>, keepalive = false): Promise<boolean> => {
      const request = async (): Promise<boolean> => {
        try {
          const res = await fetch(`/api/documents/${doc.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
            keepalive,
          });
          if (res.status === 401) {
            window.location.href = "/login";
            return false;
          }
          if (!res.ok) return false;
          setStatus("saved");
          return true;
        } catch {
          return false;
        }
      };
      const next: Promise<boolean> = saveQueue.current.then(() => request());
      saveQueue.current = next.catch(() => undefined);
      return next;
    },
    [doc.id],
  );

  // ---- content autosave -------------------------------------------------

  const flushContent = useCallback(() => {
    if (contentTimer.current) {
      clearTimeout(contentTimer.current);
      contentTimer.current = null;
    }
    const payload = pendingContent.current;
    pendingContent.current = null;
    if (payload !== null) {
      setStatus("saving");
      void patch({ content: payload });
    }
  }, [patch]);

  const scheduleContentSave = useCallback(
    (content: string) => {
      pendingContent.current = content;
      setStatus("saving");
      if (contentTimer.current) clearTimeout(contentTimer.current);
      contentTimer.current = setTimeout(flushContent, CONTENT_SAVE_DELAY_MS);
    },
    [flushContent],
  );

  const editor = useEditor({
    extensions: [StarterKit, Underline],
    content: doc.content || "",
    editable: canEdit,
    // Required with App Router SSR — the editor must only render on the client.
    immediatelyRender: false,
    onUpdate: ({ editor: instance }) =>
      scheduleContentSave(instance.getHTML()),
  });

  // If the user closes the tab while a save is pending, send it with keepalive.
  useEffect(() => {
    function onBeforeUnload() {
      const payload = pendingContent.current;
      pendingContent.current = null;
      if (contentTimer.current) clearTimeout(contentTimer.current);
      if (payload !== null) void patch({ content: payload }, true);
    }
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [patch]);

  // Clear timers if the component unmounts mid-debounce.
  useEffect(() => {
    return () => {
      if (contentTimer.current) clearTimeout(contentTimer.current);
      if (titleTimer.current) clearTimeout(titleTimer.current);
    };
  }, []);

  // ---- inline title rename ----------------------------------------------

  const saveTitle = useCallback(
    (value: string) => {
      const trimmed = value.trim();
      if (trimmed === "") {
        setTitle(savedTitle.current);
        toast("Title cannot be empty.");
        return;
      }
      if (trimmed === savedTitle.current) return;
      setStatus("saving");
      void patch({ title: trimmed }).then((ok) => {
        if (ok) {
          savedTitle.current = trimmed;
        } else {
          setTitle(savedTitle.current);
          toast("Could not rename the document.");
        }
      });
    },
    [patch, toast],
  );

  function handleTitleChange(value: string) {
    setTitle(value);
    if (!canEdit) return;
    if (titleTimer.current) clearTimeout(titleTimer.current);
    titleTimer.current = setTimeout(() => saveTitle(value), TITLE_SAVE_DELAY_MS);
  }

  // ---- delete (owner only) ----------------------------------------------

  async function deleteDocument() {
    if (
      !window.confirm(
        "Delete this document? This cannot be undone and removes it for all collaborators.",
      )
    ) {
      return;
    }
    setDeleting(true);
    try {
      const res = await fetch(`/api/documents/${doc.id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as
          | { error?: string }
          | null;
        toast(data?.error ?? "Could not delete the document.");
        return;
      }
      router.push("/");
    } catch {
      toast("Network error while deleting the document.");
    } finally {
      setDeleting(false);
    }
  }

  const statusLabel =
    status === "saving" ? (
      <span className="text-gray-400">Saving…</span>
    ) : status === "error" ? (
      <button
        type="button"
        onClick={flushContent}
        className="font-medium text-red-600 underline underline-offset-2"
      >
        Error saving – retry
      </button>
    ) : (
      <span className="text-gray-400">Saved</span>
    );

  return (
    <main className="mx-auto max-w-4xl px-4 py-6">
      <div className="flex items-center justify-between gap-3">
        <Link
          href="/"
          className="text-sm text-gray-500 transition hover:text-gray-800"
        >
          ← All documents
        </Link>
        <div className="flex items-center gap-2">
          {isOwner && (
            <button
              type="button"
              onClick={() => setShareOpen(true)}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-semibold text-white transition hover:bg-blue-700"
            >
              Share
            </button>
          )}
          {isOwner && (
            <button
              type="button"
              onClick={() => void deleteDocument()}
              disabled={deleting}
              className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 disabled:opacity-60"
            >
              {deleting ? "Deleting…" : "Delete"}
            </button>
          )}
        </div>
      </div>

      {access === "viewer" && (
        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-800">
          You have view-only access to this document.
        </div>
      )}

      {shareOpen && (
        <ShareModal documentId={doc.id} onClose={() => setShareOpen(false)} />
      )}

      <div className="mt-4">
        <input
          type="text"
          value={title}
          onChange={(e) => handleTitleChange(e.target.value)}
          disabled={!canEdit}
          maxLength={120}
          aria-label="Document title"
          placeholder="Untitled document"
          className="w-full rounded-lg border border-transparent px-2 py-1 text-2xl font-bold text-gray-900 outline-none transition placeholder:text-gray-300 hover:border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 disabled:hover:border-transparent"
        />
        <p className="mt-1 px-2 text-xs text-gray-500">
          Created by {doc.ownerName} · Updated {doc.updatedAtLabel} ·{" "}
          {statusLabel}
        </p>
      </div>

      <div className="mt-3 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        {editor ? (
          <Toolbar editor={editor} canEdit={canEdit} />
        ) : (
          <div className="h-12 border-b border-gray-200 bg-gray-50" />
        )}
        <EditorContent editor={editor} className="document-body px-6 py-6 sm:px-10" />
      </div>
    </main>
  );
}
