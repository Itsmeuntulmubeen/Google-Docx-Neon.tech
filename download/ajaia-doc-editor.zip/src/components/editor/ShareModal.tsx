"use client";

import { useEffect, useState } from "react";

type ShareRole = "VIEWER" | "EDITOR";

type Share = {
  userId: string;
  name: string;
  email: string;
  role: ShareRole;
};

export default function ShareModal({
  documentId,
  onClose,
}: {
  documentId: string;
  onClose: () => void;
}) {
  const [shares, setShares] = useState<Share[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<ShareRole>("VIEWER");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch(`/api/documents/${documentId}/shares`);
        const data = (await res.json().catch(() => null)) as
          | { shares?: Share[]; error?: string }
          | null;
        if (cancelled) return;
        if (!res.ok || !data?.shares) {
          setError(data?.error ?? "Could not load collaborators.");
          return;
        }
        setShares(data.shares);
      } catch {
        if (!cancelled) setError("Network error while loading collaborators.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [documentId]);

  async function addShare() {
    setError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/documents/${documentId}/shares`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), role }),
      });
      const data = (await res.json().catch(() => null)) as
        | { share?: Share; error?: string }
        | null;
      if (!res.ok || !data?.share) {
        setError(data?.error ?? "Could not add that collaborator.");
        return;
      }
      setShares((current) => [...current, data.share as Share]);
      setEmail("");
      setRole("VIEWER");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(userId: string, nextRole: ShareRole) {
    setShares((current) =>
      current.map((share) =>
        share.userId === userId ? { ...share, role: nextRole } : share,
      ),
    );
    try {
      const res = await fetch(`/api/documents/${documentId}/shares`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, role: nextRole }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as
          | { error?: string }
          | null;
        setError(data?.error ?? "Could not update the role.");
      }
    } catch {
      setError("Network error. Please try again.");
    }
  }

  async function removeShare(userId: string) {
    setShares((current) => current.filter((share) => share.userId !== userId));
    try {
      const res = await fetch(
        `/api/documents/${documentId}/shares?userId=${encodeURIComponent(userId)}`,
        { method: "DELETE" },
      );
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as
          | { error?: string }
          | null;
        setError(data?.error ?? "Could not remove access.");
      }
    } catch {
      setError("Network error. Please try again.");
    }
  }

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl"
        role="dialog"
        aria-modal="true"
        aria-label="Share document"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold">Share document</h2>
            <p className="mt-0.5 text-sm text-gray-500">
              Invite registered users by email. Editors can edit and rename;
              viewers can only read.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-lg p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-600"
          >
            ✕
          </button>
        </div>

        <form
          className="mt-4 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void addShare();
          }}
        >
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="teammate@demo.com"
            className="min-w-0 flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
          />
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as ShareRole)}
            className="rounded-lg border border-gray-300 px-2 py-2 text-sm outline-none focus:border-blue-500"
          >
            <option value="VIEWER">Viewer</option>
            <option value="EDITOR">Editor</option>
          </select>
          <button
            type="submit"
            disabled={busy}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60"
          >
            Add
          </button>
        </form>

        {error && (
          <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
            {error}
          </p>
        )}

        <div className="mt-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
            People with access
          </p>
          {loading ? (
            <p className="mt-2 text-sm text-gray-400">Loading…</p>
          ) : shares.length === 0 ? (
            <p className="mt-2 text-sm text-gray-400">
              Not shared with anyone yet.
            </p>
          ) : (
            <ul className="mt-2 divide-y divide-gray-100">
              {shares.map((share) => (
                <li
                  key={share.userId}
                  className="flex items-center justify-between gap-3 py-2.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900">
                      {share.name}
                    </p>
                    <p className="truncate text-xs text-gray-500">
                      {share.email}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <select
                      value={share.role}
                      onChange={(e) =>
                        void changeRole(share.userId, e.target.value as ShareRole)
                      }
                      aria-label={`Role for ${share.name}`}
                      className="rounded-lg border border-gray-300 px-2 py-1.5 text-xs outline-none focus:border-blue-500"
                    >
                      <option value="VIEWER">Viewer</option>
                      <option value="EDITOR">Editor</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => void removeShare(share.userId)}
                      aria-label={`Remove access for ${share.name}`}
                      className="rounded-lg p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-red-600"
                    >
                      ✕
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="mt-5 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-gray-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-gray-700"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
