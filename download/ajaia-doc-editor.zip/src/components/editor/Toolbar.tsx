"use client";

import type { Editor } from "@tiptap/react";

type ButtonSpec = {
  label: string;
  title: string;
  /** Extra classes to style the glyph itself (e.g. bold, underline). */
  glyphClassName?: string;
  wide?: boolean;
  active: boolean;
  enabled: boolean;
  run: () => void;
  dividerBefore?: boolean;
};

export default function Toolbar({
  editor,
  canEdit,
}: {
  editor: Editor;
  canEdit: boolean;
}) {
  const chain = () => editor.chain().focus();

  const buttons: ButtonSpec[] = [
    {
      label: "B",
      title: "Bold (Ctrl+B)",
      glyphClassName: "font-bold",
      active: editor.isActive("bold"),
      enabled: canEdit && editor.can().toggleBold(),
      run: () => chain().toggleBold().run(),
    },
    {
      label: "I",
      title: "Italic (Ctrl+I)",
      glyphClassName: "italic font-serif",
      active: editor.isActive("italic"),
      enabled: canEdit && editor.can().toggleItalic(),
      run: () => chain().toggleItalic().run(),
    },
    {
      label: "U",
      title: "Underline (Ctrl+U)",
      glyphClassName: "underline",
      active: editor.isActive("underline"),
      enabled: canEdit && editor.can().toggleUnderline(),
      run: () => chain().toggleUnderline().run(),
      dividerBefore: true,
    },
    {
      label: "H1",
      title: "Heading 1",
      glyphClassName: "text-xs font-semibold",
      active: editor.isActive("heading", { level: 1 }),
      enabled: canEdit && editor.can().toggleHeading({ level: 1 }),
      run: () => chain().toggleHeading({ level: 1 }).run(),
    },
    {
      label: "H2",
      title: "Heading 2",
      glyphClassName: "text-xs font-semibold",
      active: editor.isActive("heading", { level: 2 }),
      enabled: canEdit && editor.can().toggleHeading({ level: 2 }),
      run: () => chain().toggleHeading({ level: 2 }).run(),
    },
    {
      label: "H3",
      title: "Heading 3",
      glyphClassName: "text-xs font-semibold",
      active: editor.isActive("heading", { level: 3 }),
      enabled: canEdit && editor.can().toggleHeading({ level: 3 }),
      run: () => chain().toggleHeading({ level: 3 }).run(),
    },
    {
      label: "• List",
      title: "Bullet list",
      glyphClassName: "text-xs",
      wide: true,
      active: editor.isActive("bulletList"),
      enabled: canEdit && editor.can().toggleBulletList(),
      run: () => chain().toggleBulletList().run(),
      dividerBefore: true,
    },
    {
      label: "1. List",
      title: "Numbered list",
      glyphClassName: "text-xs",
      wide: true,
      active: editor.isActive("orderedList"),
      enabled: canEdit && editor.can().toggleOrderedList(),
      run: () => chain().toggleOrderedList().run(),
    },
    {
      label: "↶",
      title: "Undo (Ctrl+Z)",
      active: false,
      enabled: canEdit && editor.can().undo(),
      run: () => chain().undo().run(),
      dividerBefore: true,
    },
    {
      label: "↷",
      title: "Redo (Ctrl+Shift+Z)",
      active: false,
      enabled: canEdit && editor.can().redo(),
      run: () => chain().redo().run(),
    },
  ];

  return (
    <div
      className="flex flex-wrap items-center gap-1 border-b border-gray-200 px-3 py-2"
      role="toolbar"
      aria-label="Formatting"
    >
      {buttons.map((button) => (
        <span key={button.title} className="flex items-center gap-1">
          {button.dividerBefore && (
            <span className="mx-1 h-5 w-px bg-gray-200" aria-hidden />
          )}
          <button
            type="button"
            title={button.title}
            aria-label={button.title}
            aria-pressed={button.active}
            disabled={!button.enabled}
            onClick={button.run}
            className={`grid h-8 place-items-center rounded-md border border-transparent text-sm text-gray-700 transition hover:bg-gray-100 ${
              button.wide ? "px-2" : "w-8"
            } ${
              button.active
                ? "border-blue-200 bg-blue-100 text-blue-700 hover:bg-blue-100"
                : ""
            } disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent`}
          >
            <span className={button.glyphClassName}>{button.label}</span>
          </button>
        </span>
      ))}
    </div>
  );
}
