import mammoth from "mammoth";
import { marked } from "marked";

export const MAX_UPLOAD_BYTES = 2 * 1024 * 1024; // 2 MB
export const SUPPORTED_EXTENSIONS = ["txt", "md", "docx"] as const;
export type SupportedExtension = (typeof SUPPORTED_EXTENSIONS)[number];

/**
 * Browsers and OSes are inconsistent with MIME types for text files, and
 * many report `application/octet-stream` for .docx, so the allowlist is
 * deliberately forgiving there; the extension and file content still decide.
 */
const MIME_ALLOWLIST: Record<SupportedExtension, readonly string[]> = {
  txt: ["text/plain"],
  md: ["text/plain", "text/markdown", "text/x-markdown"],
  docx: [
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/zip",
    "application/x-zip-compressed",
  ],
};

const COMMON_MIMES = ["", "application/octet-stream", "application/x-empty"];

export function extensionOf(filename: string): string {
  const dot = filename.lastIndexOf(".");
  return dot === -1 ? "" : filename.slice(dot + 1).toLowerCase();
}

/**
 * Server-side validation of an uploaded file. Returns a friendly error
 * message, or null when the upload is acceptable.
 */
export function validateUpload(file: {
  name: string;
  size: number;
  type: string;
}): string | null {
  if (file.size === 0) return "The file is empty.";
  if (file.size > MAX_UPLOAD_BYTES) {
    return "File is too large. Maximum size is 2 MB.";
  }
  const ext = extensionOf(file.name);
  if (!(SUPPORTED_EXTENSIONS as readonly string[]).includes(ext)) {
    return "Unsupported file type. Supported: .txt, .md, .docx.";
  }
  const allowed = [...MIME_ALLOWLIST[ext as SupportedExtension], ...COMMON_MIMES];
  if (file.type && !allowed.includes(file.type)) {
    return `The file content ("${file.type}") does not look like a .${ext} file.`;
  }
  return null;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Plain text → one <p> per line (HTML-escaped). */
export function txtToHtml(text: string): string {
  return text
    .split(/\r?\n/)
    .map((line) => {
      const escaped = escapeHtml(line);
      return `<p>${escaped === "" ? "<br>" : escaped}</p>`;
    })
    .join("");
}

/** Markdown → HTML via marked. */
export function mdToHtml(text: string): string {
  return marked.parse(text, { async: false }) as string;
}

/** .docx → HTML via mammoth (headings, bold/italic, lists where mapped). */
export async function docxToHtml(buffer: Buffer): Promise<string> {
  const { value } = await mammoth.convertToHtml({ buffer });
  return value;
}

export function convertToHtml(
  ext: SupportedExtension,
  buffer: Buffer,
): string | Promise<string> {
  if (ext === "txt") return txtToHtml(buffer.toString("utf8"));
  if (ext === "md") return mdToHtml(buffer.toString("utf8"));
  return docxToHtml(buffer);
}

/**
 * Allowlist for imported HTML, matched to what the TipTap StarterKit +
 * Underline setup can represent. Everything else (images, tables, styles,
 * scripts…) is stripped before it reaches the database.
 */
export const sanitizeOptions = {
  allowedTags: [
    "p", "h1", "h2", "h3", "h4", "h5", "h6",
    "strong", "em", "u", "s", "del",
    "ul", "ol", "li",
    "blockquote", "code", "pre",
    "br", "hr", "a",
  ],
  allowedAttributes: {
    a: ["href", "title"],
  },
  allowedSchemes: ["http", "https", "mailto"],
};

/** "My Report 2026.docx" → "My Report 2026" (capped at 120 chars). */
export function titleFromFilename(filename: string): string {
  const base = filename.replace(/\.[^./\\]+$/, "").trim();
  const title = base === "" ? "Untitled document" : base;
  return title.length > 120 ? `${title.slice(0, 117)}...` : title;
}
