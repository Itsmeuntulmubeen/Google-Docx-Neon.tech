import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address."),
  password: z.string().min(1, "Please enter your password."),
});

export const createDocumentSchema = z.object({
  title: z
    .string()
    .trim()
    .min(1, "Title cannot be empty.")
    .max(120, "Title must be 120 characters or fewer.")
    .optional(),
});

export const updateDocumentSchema = z
  .object({
    title: z
      .string()
      .trim()
      .min(1, "Title cannot be empty.")
      .max(120, "Title must be 120 characters or fewer.")
      .optional(),
    content: z.string().max(1_000_000, "Document is too large.").optional(),
  })
  .refine((data) => data.title !== undefined || data.content !== undefined, {
    message: "Nothing to update.",
  });

export const addShareSchema = z.object({
  email: z.string().email("Please enter a valid email address."),
  role: z.enum(["VIEWER", "EDITOR"]),
});

export const updateShareSchema = z.object({
  userId: z.string().min(1, "userId is required."),
  role: z.enum(["VIEWER", "EDITOR"]),
});

export const removeShareSchema = z.object({
  userId: z.string().min(1, "userId query parameter is required."),
});
