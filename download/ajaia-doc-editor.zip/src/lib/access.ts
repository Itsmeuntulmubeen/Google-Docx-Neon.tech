import type { PrismaClient } from "@prisma/client";

export type AccessLevel = "owner" | "editor" | "viewer";

/**
 * Single source of truth for document permissions. Every API route asks this
 * helper before touching a document:
 *   'owner'  -> edit, rename, delete, share/unshare, change roles
 *   'editor' -> edit content, rename
 *   'viewer' -> read only
 *   null     -> no document with this id, or no access (callers return 404)
 *
 * `db` is injected so unit tests can run without a real database.
 */
export async function getDocumentAccess(
  db: Pick<PrismaClient, "document">,
  userId: string,
  documentId: string,
): Promise<AccessLevel | null> {
  const doc = await db.document.findUnique({
    where: { id: documentId },
    select: {
      ownerId: true,
      shares: { where: { userId }, select: { role: true } },
    },
  });
  if (!doc) return null;
  if (doc.ownerId === userId) return "owner";
  const share = doc.shares[0];
  if (!share) return null;
  return share.role === "EDITOR" ? "editor" : "viewer";
}
