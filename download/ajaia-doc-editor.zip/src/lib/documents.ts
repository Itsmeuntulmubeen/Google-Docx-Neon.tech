import type { PrismaClient } from "@prisma/client";

export type OwnedDocumentItem = {
  id: string;
  title: string;
  updatedAt: string;
  updatedAtLabel: string;
};

export type SharedDocumentItem = OwnedDocumentItem & {
  ownerName: string;
  /** Role of the current user on this document: "Viewer" or "Editor". */
  role: "Viewer" | "Editor";
};

const DATE_FORMAT: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
};

function label(date: Date): string {
  return date.toLocaleString("en-US", DATE_FORMAT);
}

/**
 * Documents for the dashboard, split into the two tabs.
 * Formatted labels are produced here (server-side) so the client never
 * re-formats dates — avoids hydration mismatches.
 */
export async function listDocumentsForUser(db: PrismaClient, userId: string) {
  const [ownedRows, sharedRows] = await Promise.all([
    db.document.findMany({
      where: { ownerId: userId },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true, updatedAt: true },
    }),
    db.document.findMany({
      where: { shares: { some: { userId } } },
      orderBy: { updatedAt: "desc" },
      select: {
        id: true,
        title: true,
        updatedAt: true,
        owner: { select: { name: true } },
        shares: {
          where: { userId },
          select: { role: true },
        },
      },
    }),
  ]);

  const owned: OwnedDocumentItem[] = ownedRows.map((doc) => ({
    id: doc.id,
    title: doc.title,
    updatedAt: doc.updatedAt.toISOString(),
    updatedAtLabel: label(doc.updatedAt),
  }));

  const shared: SharedDocumentItem[] = sharedRows.map((doc) => ({
    id: doc.id,
    title: doc.title,
    updatedAt: doc.updatedAt.toISOString(),
    updatedAtLabel: label(doc.updatedAt),
    ownerName: doc.owner.name,
    role: doc.shares[0]?.role === "EDITOR" ? "Editor" : "Viewer",
  }));

  return { owned, shared };
}
