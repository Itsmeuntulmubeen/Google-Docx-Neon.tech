import { NextResponse } from "next/server";
import { ZodError, type ZodSchema } from "zod";

/** All API errors share one shape: `{ "error": string }`. */
export function jsonError(message: string, status: number): NextResponse {
  return NextResponse.json({ error: message }, { status });
}

/** Parses a JSON body; returns null instead of throwing on malformed input. */
export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return null;
  }
}

/** Validates a body against a zod schema and returns the first error message. */
export function validate<T>(
  schema: ZodSchema<T>,
  data: unknown,
): { ok: true; data: T } | { ok: false; message: string } {
  const result = schema.safeParse(data);
  if (result.success) return { ok: true, data: result.data };
  const issue = result.error.issues[0];
  const field = issue?.path.join(".");
  return {
    ok: false,
    message: issue ? (field ? `${field}: ${issue.message}` : issue.message) : "Invalid input.",
  };
}

export function zodErrorMessage(error: ZodError): string {
  const issue = error.issues[0];
  return issue ? issue.message : "Invalid input.";
}
