export default function DashboardLoading() {
  return (
    <div className="animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-40 rounded bg-gray-200" />
        <div className="h-9 w-36 rounded-lg bg-gray-200" />
      </div>
      <div className="mt-6 h-9 w-72 rounded bg-gray-200" />
      <ul className="mt-4 space-y-3">
        {[1, 2, 3].map((i) => (
          <li
            key={i}
            className="h-16 rounded-xl border border-gray-200 bg-white"
          />
        ))}
      </ul>
    </div>
  );
}
