import { getSessionUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { listDocumentsForUser } from "@/lib/documents";
import Header from "@/components/Header";
import DashboardClient from "@/components/dashboard/DashboardClient";

export default async function DashboardPage() {
  const user = await getSessionUser();
  if (!user) return null; // Middleware redirects unauthenticated visitors.

  const { owned, shared } = await listDocumentsForUser(prisma, user.userId);

  return (
    <>
      <Header userName={user.name} />
      <main className="mx-auto max-w-5xl px-4 py-8">
        <DashboardClient owned={owned} shared={shared} />
      </main>
    </>
  );
}
