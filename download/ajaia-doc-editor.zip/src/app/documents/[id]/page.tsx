import { notFound } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { getDocumentAccess } from "@/lib/access";
import Header from "@/components/Header";
import DocumentEditor from "@/components/editor/DocumentEditor";

export default async function DocumentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) notFound();

  const access = await getDocumentAccess(prisma, user.userId, id);
  if (!access) notFound();

  const doc = await prisma.document.findUnique({
    where: { id },
    include: { owner: { select: { name: true } } },
  });
  if (!doc) notFound();

  const updatedAtLabel = doc.updatedAt.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  return (
    <>
      <Header userName={user.name} />
      <DocumentEditor
        doc={{
          id: doc.id,
          title: doc.title,
          content: doc.content,
          ownerName: doc.owner.name,
          updatedAtLabel,
        }}
        access={access}
      />
    </>
  );
}
