export default function DocumentLoading() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="h-10 w-2/3 animate-pulse rounded bg-gray-200" />
      <div className="mt-4 h-9 w-full animate-pulse rounded-lg bg-gray-200" />
      <div className="mt-6 space-y-3">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-4 w-full animate-pulse rounded bg-gray-100" />
        ))}
      </div>
    </div>
  );
}
