import { NextResponse } from "next/server";
import sanitizeHtml from "sanitize-html";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { jsonError } from "@/lib/api";
import {
  MAX_UPLOAD_BYTES,
  convertToHtml,
  extensionOf,
  sanitizeOptions,
  titleFromFilename,
  validateUpload,
  type SupportedExtension,
} from "@/lib/import";

export const runtime = "nodejs"; // mammoth/sanitize-html need the Node runtime.

/**
 * POST /api/import — multipart form with a single `file` field (.txt, .md or
 * .docx, max 2 MB). Converts the file to sanitized HTML and creates a new
 * document owned by the caller.
 */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);

  let form: FormData | null = null;
  try {
    form = await req.formData();
  } catch {
    return jsonError("Expected a multipart form upload with a file field.", 400);
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return jsonError("No file was provided.", 400);
  }

  const uploadError = validateUpload({
    name: file.name,
    size: file.size,
    type: file.type,
  });
  if (uploadError) return jsonError(uploadError, 400);

  const buffer = Buffer.from(await file.arrayBuffer());
  if (buffer.byteLength > MAX_UPLOAD_BYTES) {
    return jsonError("File is too large. Maximum size is 2 MB.", 400);
  }

  const ext = extensionOf(file.name) as SupportedExtension;

  let html: string;
  try {
    const converted = convertToHtml(ext, buffer);
    html =
      converted instanceof Promise ? await converted : converted;
  } catch {
    return jsonError(
      `Could not read the .${ext} file. It may be corrupted or not a real .${ext} document.`,
      400,
    );
  }

  const safeHtml = sanitizeHtml(html, sanitizeOptions);

  const doc = await prisma.document.create({
    data: {
      ownerId: user.userId,
      title: titleFromFilename(file.name),
      content: safeHtml,
    },
    select: { id: true, title: true },
  });

  return NextResponse.json({ document: doc }, { status: 201 });
}
