import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { getDocumentAccess } from "@/lib/access";
import { jsonError, readJson, validate } from "@/lib/api";
import {
  addShareSchema,
  removeShareSchema,
  updateShareSchema,
} from "@/lib/validation";

type RouteContext = { params: Promise<{ id: string }> };

/** Only owners may manage sharing; other callers get 404/403. */
async function requireOwner(documentId: string, userId: string) {
  const access = await getDocumentAccess(prisma, userId, documentId);
  if (!access) return { error: jsonError("Document not found.", 404) };
  if (access !== "owner") {
    return {
      error: jsonError(
        "Only the owner can manage sharing for this document.",
        403,
      ),
    };
  }
  return {};
}

function serializeShare(share: {
  userId: string;
  role: "VIEWER" | "EDITOR";
  user: { name: string; email: string };
}) {
  return {
    userId: share.userId,
    name: share.user.name,
    email: share.user.email,
    role: share.role,
  };
}

/** GET /api/documents/[id]/shares — list collaborators (owner only). */
export async function GET(_req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const { error } = await requireOwner(id, user.userId);
  if (error) return error;

  const shares = await prisma.documentShare.findMany({
    where: { documentId: id },
    orderBy: { createdAt: "asc" },
    include: { user: { select: { name: true, email: true } } },
  });

  return NextResponse.json({ shares: shares.map(serializeShare) });
}

/** POST /api/documents/[id]/shares — grant access to an existing user. */
export async function POST(req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const { error } = await requireOwner(id, user.userId);
  if (error) return error;

  const parsed = validate(addShareSchema, await readJson(req));
  if (!parsed.ok) return jsonError(parsed.message, 400);

  const email = parsed.data.email.toLowerCase();
  if (email === user.email.toLowerCase()) {
    return jsonError("You cannot share a document with yourself.", 400);
  }

  const target = await prisma.user.findUnique({ where: { email } });
  if (!target) {
    return jsonError("No user was found with that email address.", 404);
  }

  const existing = await prisma.documentShare.findUnique({
    where: { documentId_userId: { documentId: id, userId: target.id } },
  });
  if (existing) {
    return jsonError(
      "That user already has access to this document.",
      409,
    );
  }

  const share = await prisma.documentShare.create({
    data: {
      documentId: id,
      userId: target.id,
      role: parsed.data.role,
    },
    include: { user: { select: { name: true, email: true } } },
  });

  return NextResponse.json({ share: serializeShare(share) }, { status: 201 });
}

/** PATCH /api/documents/[id]/shares — change a collaborator's role. */
export async function PATCH(req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const { error } = await requireOwner(id, user.userId);
  if (error) return error;

  const parsed = validate(updateShareSchema, await readJson(req));
  if (!parsed.ok) return jsonError(parsed.message, 400);

  const existing = await prisma.documentShare.findUnique({
    where: { documentId_userId: { documentId: id, userId: parsed.data.userId } },
  });
  if (!existing) {
    return jsonError("That user does not have access to this document.", 404);
  }

  const share = await prisma.documentShare.update({
    where: { documentId_userId: { documentId: id, userId: parsed.data.userId } },
    data: { role: parsed.data.role },
    include: { user: { select: { name: true, email: true } } },
  });

  return NextResponse.json({ share: serializeShare(share) });
}

/** DELETE /api/documents/[id]/shares?userId=… — revoke access. */
export async function DELETE(req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const { error } = await requireOwner(id, user.userId);
  if (error) return error;

  const userId = new URL(req.url).searchParams.get("userId");
  const parsed = validate(removeShareSchema, { userId });
  if (!parsed.ok) return jsonError(parsed.message, 400);

  const existing = await prisma.documentShare.findUnique({
    where: { documentId_userId: { documentId: id, userId: parsed.data.userId } },
  });
  if (!existing) {
    return jsonError("That user does not have access to this document.", 404);
  }

  await prisma.documentShare.delete({
    where: { documentId_userId: { documentId: id, userId: parsed.data.userId } },
  });

  return NextResponse.json({ ok: true });
}
