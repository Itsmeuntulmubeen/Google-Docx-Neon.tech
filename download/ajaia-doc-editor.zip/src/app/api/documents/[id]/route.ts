import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { getDocumentAccess } from "@/lib/access";
import { jsonError, readJson, validate } from "@/lib/api";
import { updateDocumentSchema } from "@/lib/validation";

type RouteContext = { params: Promise<{ id: string }> };

/** GET /api/documents/[id] — fetch one document (any access level). */
export async function GET(_req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const access = await getDocumentAccess(prisma, user.userId, id);
  if (!access) return jsonError("Document not found.", 404);

  const doc = await prisma.document.findUnique({
    where: { id },
    include: { owner: { select: { name: true } } },
  });
  if (!doc) return jsonError("Document not found.", 404);

  return NextResponse.json({
    document: {
      id: doc.id,
      title: doc.title,
      content: doc.content,
      createdAt: doc.createdAt.toISOString(),
      updatedAt: doc.updatedAt.toISOString(),
      ownerName: doc.owner.name,
    },
    access,
  });
}

/**
 * PATCH /api/documents/[id] — update title and/or content.
 * Owners and editors may write; viewers get 403.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const access = await getDocumentAccess(prisma, user.userId, id);
  if (!access) return jsonError("Document not found.", 404);
  if (access === "viewer") {
    return jsonError("You have view-only access to this document.", 403);
  }

  const parsed = validate(updateDocumentSchema, await readJson(req));
  if (!parsed.ok) return jsonError(parsed.message, 400);

  try {
    const doc = await prisma.document.update({
      where: { id },
      data: {
        ...(parsed.data.title !== undefined && { title: parsed.data.title }),
        ...(parsed.data.content !== undefined && {
          content: parsed.data.content,
        }),
      },
      select: { id: true, title: true, updatedAt: true },
    });
    return NextResponse.json({
      document: { ...doc, updatedAt: doc.updatedAt.toISOString() },
    });
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2025"
    ) {
      return jsonError("Document not found.", 404);
    }
    throw error;
  }
}

/** DELETE /api/documents/[id] — owner only. */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await params;

  const access = await getDocumentAccess(prisma, user.userId, id);
  if (!access) return jsonError("Document not found.", 404);
  if (access !== "owner") {
    return jsonError("Only the owner can delete this document.", 403);
  }

  try {
    await prisma.document.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2025"
    ) {
      return jsonError("Document not found.", 404);
    }
    throw error;
  }
}
