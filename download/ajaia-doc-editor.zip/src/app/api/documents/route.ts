import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { jsonError, readJson, validate } from "@/lib/api";
import { createDocumentSchema } from "@/lib/validation";
import { listDocumentsForUser } from "@/lib/documents";

/** GET /api/documents — list documents owned by and shared with the caller. */
export async function GET() {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);

  const documents = await listDocumentsForUser(prisma, user.userId);
  return NextResponse.json(documents);
}

/** POST /api/documents — create a new empty document owned by the caller. */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return jsonError("Unauthorized", 401);

  const body = await readJson(req);
  const parsed = validate(createDocumentSchema, body ?? {});
  if (!parsed.ok) return jsonError(parsed.message, 400);

  const doc = await prisma.document.create({
    data: {
      ownerId: user.userId,
      title: parsed.data.title ?? "Untitled document",
      content: "",
    },
    select: { id: true, title: true },
  });

  return NextResponse.json({ document: doc }, { status: 201 });
}
