# Architecture

Short notes on the stack choices, data model, permission model, and the
trade-offs I made within the 4–6 hour timebox.

## Stack choices

- **Next.js 15 (App Router) + TypeScript strict + Tailwind 4.** One codebase
  for UI and REST API; React Server Components keep the dashboard fast
  (data is fetched directly from Prisma server-side, no client waterfalls).
  Tailwind keeps styling fast without a design-system detour.
- **TipTap v2 (StarterKit + Underline).** The brief asked for exactly this
  combination. It gives ProseMirror's document model with a small API surface;
  `editor.getHTML()` is the single serialization step, and the same HTML loads
  back with `content:` on mount. v2 (not v3) was pinned deliberately because
  the brief specifies "StarterKit + Underline extension" as separate packages
  (v3 merges Underline into StarterKit).
- **PostgreSQL via Prisma 6.** The brief requires it. The schema ships with a
  real migration (`prisma/migrations`), so `migrate deploy` works on any
  Postgres — local Docker or Neon.
- **Auth: `jose` JWT in an httpOnly cookie.** No third-party auth per the
  brief. `jose` works in both the Edge runtime (middleware) and Node
  (route handlers), so one verification primitive serves both. Passwords are
  bcrypt-hashed by the seed and the login route — even a demo should not store
  plaintext passwords.
- **`zod` on every input.** Each route handler parses its body/query through a
  schema (`src/lib/validation.ts`); failures return `400 { error }` with the
  first issue's message.
- **Import: `mammoth` + `marked` + `sanitize-html`.** mammoth gives clean
  semantic HTML from .docx (headings/bold/italic/lists), marked handles .md,
  and everything passes an allowlist sanitizer before it touches the database.

## Data model

```
User            Document                    DocumentShare
├─ id           ├─ id                       ├─ documentId ─┐
├─ email (uq)   ├─ title ("Untitled…")      ├─ userId ─────┤ unique(documentId, userId)
├─ name         ├─ content (HTML string)    ├─ role: VIEWER | EDITOR
├─ passwordHash ├─ ownerId → User           └─ createdAt
└─ createdAt    ├─ createdAt / updatedAt
```

- `Document.content` is **sanitized HTML**. Storing HTML (rather than TipTap
  JSON) was a deliberate call: it is one representation for editing, import,
  and storage; it round-trips through `mammoth`/`marked` without conversion;
  and it degrades gracefully (any HTML is viewable). The brief allows either.
- `DocumentShare` has a composite unique on `[documentId, userId]` — the
  duplicate-share error (409) maps to a pre-checked find + the DB constraint.
- `onDelete: Cascade` on both relations: deleting a document removes its
  shares; deleting a user removes their shares (owned documents cascade too).

## Permission model

Three levels, one source of truth:

| Level  | Capabilities                                        |
| ------ | --------------------------------------------------- |
| owner  | edit, rename, delete, share/unshare, change roles   |
| editor | edit content, rename                                |
| viewer | read only                                           |

`getDocumentAccess(db, userId, documentId)` (`src/lib/access.ts`) resolves a
user to `'owner' | 'editor' | 'viewer' | null` in a single query. Enforcement
is layered:

1. **Middleware** (`src/middleware.ts`) verifies the JWT cookie for every page
   and API route (401 JSON for `/api/*`, redirect for pages).
2. **Route handlers** call `getDocumentAccess` and return **404** when the
   caller has no relation to the document (existence is not leaked) and **403**
   when they relate but lack the required level (viewer write attempts).
3. **The UI** merely mirrors what the server already enforces: read-only
   editor + banner for viewers, Share/Delete buttons only for owners.

The helper takes the Prisma client as a parameter (dependency injection), so
its unit tests run without a database; the API-level tests mock the module
boundary and drive the real route handlers.

## Import pipeline

`POST /api/import` (multipart): **extension allowlist → MIME allowlist →
size ≤ 2 MB (declared and actual bytes) → convert (`txt`/`md`/`docx`) →
`sanitize-html` allowlist → create document**. Title = filename without
extension, capped at 120 chars. The MIME allowlist is deliberately forgiving
for `application/octet-stream`/empty types (OS-dependent behavior), while
extension and size are strict. The sanitizer's allowlist matches what
StarterKit + Underline can represent, so imported content never contains
elements the editor would drop silently.

## What was prioritized and why

1. **Server-enforced permissions end-to-end** — for a *collaborative* editor,
   sharing bugs are the worst class of bug; the access helper + its tests +
   API-level sharing tests came before editor polish.
2. **Reliable persistence** — autosave with a serialized request queue (no
   stale overwrites), "Saving…/Saved/Error – retry" status, keepalive flush on
   tab close, server-side validation mirrored on the client.
3. **Honest import errors** — friendly, specific messages for wrong type,
   oversize, and corrupt files instead of a generic 500.
4. **Clean, readable code** — small modules with single responsibilities,
   no clever abstractions, strict TypeScript with no `any`.

## What was deliberately cut (and why)

- **Real-time collaboration (CRDT/OT, presence, cursors).** Genuinely hard;
  Yjs + a sync server would consume the whole timebox. Autosave + shares is
  the honest scope for "lightweight collaborative".
- **Comments, mentions, notifications.** Requires a data model and UI surface
  of their own; nothing in the core flow depends on them.
- **Rich media (images, tables, embeds).** StarterKit has no table/image
  nodes; the sanitizer strips them from imports rather than silently
  truncating documents that contain them.
- **Public share links.** Email-invite sharing with roles was the specified
  model; anonymous links would need a separate permission path.
- **Export.** (Stretch option; not needed once import + HTML storage work.)
- **Version history.** (Stretch option; skipped in favor of test depth.)
- **Password reset, email verification.** Simulated auth per the brief.

## Known limitations

- **Last-write-wins concurrency.** If two editors type in the same paragraph
  at the same moment, the later PATCH overwrites the earlier one. No OT/CRDT.
- **Autosave window.** Saves fire ~1s after the last keystroke; a hard crash
  within that window can lose the final keystrokes (a keepalive flush covers
  normal tab close).
- **Title-rename race.** Title and content PATCHes are serialized per client,
  but two clients renaming simultaneously can interleave.
- **MIME allowlist is advisory.** A malicious `.exe` renamed to `.docx` is
  rejected by zip parsing (mammoth throws → 400), but content sniffing is not
  exhaustive; sanitized HTML output means stored content is inert regardless.
- **Users must exist before sharing.** No invitations to unknown emails
  (per the brief: "Enter an existing user's email").
- **HTML strings can be large.** Content is capped at 1 MB per PATCH; no
  pagination or lazy loading for very long documents.
- **No rate limiting** on login attempts (demo scope).
- **Sessions last 7 days** and are not revocable individually (logout clears
  the cookie only); rotate `AUTH_SECRET` to invalidate all sessions.
