import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const DEMO_USERS = [
  { email: "alice@demo.com", name: "Alice" },
  { email: "bob@demo.com", name: "Bob" },
  { email: "carol@demo.com", name: "Carol" },
];

const DEMO_PASSWORD = "demo1234";

async function main() {
  for (const user of DEMO_USERS) {
    const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
    await prisma.user.upsert({
      where: { email: user.email },
      update: {},
      create: { ...user, passwordHash },
    });
    console.log(`Seeded user ${user.name} <${user.email}>`);
  }
  console.log(`All demo users use the password "${DEMO_PASSWORD}".`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
