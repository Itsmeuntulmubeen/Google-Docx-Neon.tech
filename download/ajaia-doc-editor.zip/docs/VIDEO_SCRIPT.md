# Video script outline (3–5 minutes)

> Paste the finished recording link into WALKTHROUGH.txt. Timestamps are a
> guide for a ~4-minute cut.

## 0:00–0:20 — Intro

- "Hi, I'm <name>. This is my take-home for Ajaia: a lightweight
  Google-Docs-style collaborative editor."
- One sentence on the stack: "Next.js App Router, TypeScript, TipTap,
  Postgres via Prisma, deployed on Vercel with a Neon database."
- Show the login page briefly; mention the demo accounts box.

## 0:20–1:10 — Main flow: create, edit, autosave

- One-click sign in as Alice.
- Dashboard: point out "My documents" vs "Shared with me" tabs, Owner badge,
  updated times.
- Click **+ New document** → editor opens.
- Type a heading, some bold/italic text, a bullet list — show toolbar active
  states as you toggle them.
- Point at the status text: **Saving… → Saved**.
- Rename the document inline ("Project Phoenix") — status flips to Saving… →
  Saved.
- **Reload the page** — formatting and title persist ("content is stored as
  sanitized HTML in Postgres").

## 1:10–1:55 — Import

- Back to dashboard → **Import file** → drag & drop a .docx (or .md) file.
- Show the "Supported: .txt, .md, .docx, max 2 MB" hint in the modal.
- The converted document opens with headings/bold/italics intact.
- (If time: show a rejection — drop a .pdf, friendly error appears.)

## 1:55–3:10 — Sharing & permissions

- As Alice, open the doc → **Share**.
- Type `bob@demo.com`, role **Viewer**, Add. Then show the error paths:
  unknown email (404 message), self-share, duplicate.
- Log out, one-click sign in as Bob.
- Document shows under **Shared with me** with "Shared by Alice · Viewer".
- Open it: **"You have view-only access"** banner, toolbar disabled, typing
  does nothing.
- Log out → Alice → Share → upgrade Bob to **Editor**.
- Log out → Bob → reload: toolbar enabled, edits and renames work — but no
  Share/Delete buttons ("the UI hides them, and the API enforces it — every
  route calls one getDocumentAccess helper").

## 3:10–3:50 — Key decisions & what was cut

- Permissions enforced server-side in every route (403/404 semantics; the UI
  only mirrors what the server guarantees).
- HTML storage choice: one representation for edit/import/storage.
- Deliberately cut: real-time collaboration (OT/CRDT), comments, rich media,
  export/version-history stretch — "lightweight" scope, documented in
  ARCHITECTURE.md.
- Quality gates: 41 Vitest tests (access control, import conversion with a
  real .docx fixture, API-level sharing tests), ESLint + strict TS, clean
  production build.

## 3:50–4:15 — How AI helped + close

- Two or three honest sentences on AI usage (matching AI_WORKFLOW.md):
  what it accelerated, what you rejected/rewrote, how you verified its output.
- Close: "Code, architecture notes, and QA script are in the repo. Thanks!"

---

### Recording checklist

- [ ] 1280×800 or larger window; browser zoom 100%
- [ ] Seed the DB first (`npm run db:seed`) so demo accounts exist
- [ ] Prepare the .docx/.md import files on the desktop beforehand
- [ ] Do one full dry run before recording
- [ ] Paste the final URL into WALKTHROUGH.txt
